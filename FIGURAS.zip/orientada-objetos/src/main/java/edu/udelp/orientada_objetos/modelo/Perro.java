package edu.udelp.orientada_objetos.modelo;

public class Perro  extends Animal{

	@Override
	public void sonido() {
		// TODO Auto-generated method stub
		super.sonido();
		System.out.println("LADRA");
	}

}
