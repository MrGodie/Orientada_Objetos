package edu.udelp.orientada_objetos.modelo;
import lombok.Data;
@Data
public class Triangulo {
	
	private Double lado1;
	private Double lado2;
	private Double lado3;
	
	

}
