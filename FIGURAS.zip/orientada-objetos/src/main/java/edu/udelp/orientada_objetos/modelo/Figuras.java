package edu.udelp.orientada_objetos.modelo;

public class Figuras {

}
