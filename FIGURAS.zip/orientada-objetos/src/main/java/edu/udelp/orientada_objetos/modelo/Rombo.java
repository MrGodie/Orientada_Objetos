package edu.udelp.orientada_objetos.modelo;

import lombok.Data;

@Data
public class Rombo {
	
	private Double lado;
	
	private Double diagonalMenor;
	
	private Double diagonalMayor;

}
