package edu.udelp.orientada_objetos.proceso;
import edu.udelp.orientada_objetos.modelo.Rectangulo;
public class RectanguloProceso {
	
	public Double perimetro(Rectangulo rectangulo) {
		return (rectangulo.getAlto() + rectangulo.getLargo())*2;
	}
	
	public Double area (Rectangulo rectangulo) {
		return rectangulo.getAlto() * rectangulo.getLargo();
	}
	
	

}
