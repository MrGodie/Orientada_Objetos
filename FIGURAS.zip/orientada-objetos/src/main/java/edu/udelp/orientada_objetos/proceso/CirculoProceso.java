package edu.udelp.orientada_objetos.proceso;
import edu.udelp.orientada_objetos.modelo.Circulo;
public class CirculoProceso {
	
	public Double perimetro(Circulo circulo) {
		return circulo.getDiametro() * Math.PI;
	}
	
	public Double area (Circulo circulo) {
		return Math.pow((circulo.getDiametro()/2), 2) * Math.PI;
	}

}
