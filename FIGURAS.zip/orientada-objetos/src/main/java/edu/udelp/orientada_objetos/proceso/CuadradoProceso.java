package edu.udelp.orientada_objetos.proceso;
import edu.udelp.orientada_objetos.modelo.Cuadrado;
public class CuadradoProceso {
	
	public Double perimetro(Cuadrado cuadrado) {
		return (cuadrado.getLado() *4);
	}
	
	public Double area(Cuadrado cuadrado) {
		return (cuadrado.getLado() * cuadrado.getLado());
	}

}
