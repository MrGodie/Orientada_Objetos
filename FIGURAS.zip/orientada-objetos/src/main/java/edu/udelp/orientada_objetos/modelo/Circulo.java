package edu.udelp.orientada_objetos.modelo;
import lombok.Data;
@Data
public class Circulo  extends Figuras{
	private Double Diametro;

	

}
