package edu.udelp.orientada_objetos.modelo;
import lombok.Data;
@Data

public class Circulo  extends Figuras{
	private Double Diametro;

	public Double getDiametro() {
		return Diametro;
	}

	public void setDiametro(Double diametro) {
		Diametro = diametro;
	}

}
