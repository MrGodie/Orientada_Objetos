package edu.udelp.orientada_objetos.proceso;
import edu.udelp.orientada_objetos.modelo.PoligonoN;
public class PoligonoProceso {
	
	public Double perimetro(PoligonoN poligono) {
		return poligono.getNumeroLados() * poligono.getLado();
	}
	
	public Double area(PoligonoN poligono) {
		return (perimetro(poligono) * poligono.getApotema())/2;
	}

}
