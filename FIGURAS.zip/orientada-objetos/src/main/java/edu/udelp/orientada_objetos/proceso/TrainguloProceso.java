package edu.udelp.orientada_objetos.proceso;
import edu.udelp.orientada_objetos.modelo.Triangulo;
public class TrainguloProceso {
	
	public Double perimetro(Triangulo triangulo) {
		return triangulo.getLado1() + triangulo.getLado2() + triangulo.getLado3();
	}
	
	public Double area(Triangulo triangulo) {
		double area = 0;
		double altura = Math.sqrt(Math.pow(triangulo.getLado2(), 2) - Math.pow((triangulo.getLado3()/2),2));
		area = (triangulo.getLado3() * altura)/2;
		return area;
	}

}
