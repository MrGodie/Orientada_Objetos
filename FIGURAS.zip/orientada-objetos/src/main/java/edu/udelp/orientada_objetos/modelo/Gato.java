package edu.udelp.orientada_objetos.modelo;

public class Gato extends Animal{

	@Override
	public void sonido() {
		// TODO Auto-generated method stub
		super.sonido();
		System.out.println("MIU");
	}

}
