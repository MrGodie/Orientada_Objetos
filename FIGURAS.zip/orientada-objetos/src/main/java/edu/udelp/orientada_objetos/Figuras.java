package edu.udelp.orientada_objetos;
import edu.udelp.orientada_objetos.modelo.*;
import edu.udelp.orientada_objetos.proceso.*;
public class Figuras {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cuadrado c = new Cuadrado();
		
		c.setLado(7D);
		
		Rectangulo r = new Rectangulo();
		r.setAlto(3D);
		r.setLargo(5D);
		
		Triangulo t = new Triangulo();
		t.setLado1(5D);
		t.setLado2(5D);
		t.setLado3(5D);
		
		PoligonoN p = new PoligonoN();
		p.setLado(5D);
		p.setNumeroLados(5);
		p.setApotema(3D);
	
		
		Circulo ci = new Circulo();
		ci.setDiametro(8D);
		
		Rombo ro = new Rombo();
		ro.setLado(5D);
		ro.setDiagonalMenor(4D);
		ro.setDiagonalMayor(7D);
		
		CuadradoProceso processC = new CuadradoProceso();
		System.out.println("CUADRADO");
		System.out.println(processC.perimetro(c));
		System.out.println(processC.area(c));
		System.out.println("");
		
		RectanguloProceso processR = new RectanguloProceso();
		System.out.println("RECTANGULO");
		System.out.println(processR.perimetro(r));
		System.out.println(processR.area(r));
		System.out.println("");

		PoligonoProceso processP = new PoligonoProceso();
		System.out.println("POLIGONO");
		System.out.println(processP.perimetro(p));
		System.out.println(processP.area(p));
		System.out.println("");
		
		TrainguloProceso processT = new TrainguloProceso();
		System.out.println("CIRCULO");
		System.out.println(processT.perimetro(t));
		System.out.println(processT.area(t));
		System.out.println("");	

		CirculoProceso processCi = new CirculoProceso();
		System.out.println("CIRCULO");
		System.out.println(processCi.perimetro(ci));
		System.out.println(processCi.area(ci));
		System.out.println("");	
		
		RomboProceso processRo = new RomboProceso();
		System.out.println("Rombo");
		System.out.println(processRo.perimetro(ro));
		System.out.println(processRo.area(ro));
		System.out.println("");	

		

	}

}
