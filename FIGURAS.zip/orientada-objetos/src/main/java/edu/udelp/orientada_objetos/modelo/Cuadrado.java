package edu.udelp.orientada_objetos.modelo;
import lombok.Data;
@Data
public class Cuadrado extends Figuras {
	private Double lado;

	public Double getLado() {
		return lado;
	}

	public void setLado(Double lado) {
		this.lado = lado;
	}
}

