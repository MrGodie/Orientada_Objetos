package edu.udelp.orientada_objetos.modelo;
import lombok.Data;
@Data
public class PoligonoN {
	
	private Integer numeroLados;
	
	private Double lado;
	
	private Double apotema;

	public Integer getNumeroLados() {
		return numeroLados;
	}

	public void setNumeroLados(Integer numeroLados) {
		this.numeroLados = numeroLados;
	}

	public Double getLado() {
		return lado;
	}

	public void setLado(Double lado) {
		this.lado = lado;
	}

	public Double getApotema() {
		return apotema;
	}

	public void setApotema(Double apotema) {
		this.apotema = apotema;
	}

	

}
