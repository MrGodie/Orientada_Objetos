package edu.udelp.orientada_objetos.modelo;
import lombok.Data;
@Data
public class PoligonoN {
	
	private Integer numeroLados;
	
	private Double lado;
	
	private Double apotema;



	

}
