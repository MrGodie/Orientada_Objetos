package edu.udelp.orientada_objetos.modelo;
import edu.udelp.orientada_objetos.modelo.Animal;
public class SonidoAnimal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a = new Animal();
		a.sonido();
		a = new Perro();
		a.sonido();
		a = new Gato();
		a.sonido();

	}

}
