package edu.udelp.orientada_objetos.modelo;
import lombok.Data;
@Data
public class Rectangulo extends Figuras {
	
	private Double alto;
	
	private Double largo;

	public Double getAlto() {
		return alto;
	}

	public void setAlto(Double alto) {
		this.alto = alto;
	}

	public Double getLargo() {
		return largo;
	}

	public void setLargo(Double largo) {
		this.largo = largo;
	}


}
