package edu.udelp.orientada_objetos.modelo;
import lombok.Data;
@Data
public class Rectangulo extends Figuras {
	
	private Double alto;
	
	private Double largo;



}
